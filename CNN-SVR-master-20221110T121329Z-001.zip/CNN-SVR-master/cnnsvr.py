# -*- coding:utf-8 -*-

import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# import tensorflow as tf
# import keras.backend.tensorflow_backend as KTF
#
# config = tf.ConfigProto()
# config.gpu_options.per_process_gpu_memory_fraction = 0.95
# session = tf.Session(config=config)
#
# KTF.set_session(session)

from keras.models import Model
from keras.layers import Input
from keras.layers.core import Dense, Dropout, Activation, Flatten
from keras.layers.convolutional import Convolution1D, AveragePooling1D
#from keras.layers.merge import concatenate
from keras.layers import concatenate

import numpy as np
import pandas as pd
from sklearn.svm import SVR
from sklearn.svm import SVC
import scipy.stats as stats
from sklearn.metrics import confusion_matrix, accuracy_score, roc_auc_score, roc_curve
from sklearn.metrics import classification_report
from scipy import stats
import numpy as np
from sklearn.model_selection import RandomizedSearchCV
from scipy.stats import reciprocal, uniform
from sklearn.metrics import accuracy_score
from sklearn.model_selection import GridSearchCV, cross_val_score, KFold


def grna_preprocess(lines):
    length = 23
    data_n = len(lines)
    seq = np.zeros((data_n, length, 4), dtype=int)
    for l in range(data_n):
        data = lines[l]
        seq_temp = data
        for i in range(length):
            if seq_temp[i] in "Aa":
                seq[l, i, 0] = 1
            elif seq_temp[i] in "Cc":
                seq[l, i, 1] = 1
            elif seq_temp[i] in "Gg":
                seq[l, i, 2] = 1
            elif seq_temp[i] in "Tt":
                seq[l, i, 3] = 1
    return seq



def epi_preprocess(lines):
    length = 23
    data_n = len(lines)
    epi = np.zeros((data_n, length), dtype=int)
    for l in range(data_n):
        data = lines[l]
        epi_temp = data
        for i in range(length):
            if epi_temp[i] in "A":
                epi[l, i] = 1
            elif epi_temp[i] in "N":
                epi[l, i] = 0
    return epi

def preprocess(file_path, usecols):
    data = pd.read_csv(file_path, usecols=usecols)
    data = np.array(data)
    ctcf, dnase, h3k4me3, rrbs = epi_preprocess(data[:, 0]), epi_preprocess(data[:, 1]), epi_preprocess(data[:, 2]), epi_preprocess(data[:, 3])
    epi = []
    for i in range(len(data)):
        ctcf_t, dnase_t, h3k4me3_t, rrbs_t = pd.DataFrame(ctcf[i]), pd.DataFrame(dnase[i]), pd.DataFrame(h3k4me3[i]), pd.DataFrame(rrbs[i])
        epi_t = pd.concat([ctcf_t, dnase_t, h3k4me3_t, rrbs_t], axis=1)
        epi_t = np.array(epi_t)
        epi.append(epi_t)
    epi = np.array(epi)
    return epi

def load_data(train_file, test_file):
    train_data = pd.read_csv(train_file, usecols=[5, 10])
    train_data = np.array(train_data)
    train_seq, train_y = train_data[:, 0], train_data[:, 1]
    train_seq = grna_preprocess(train_seq)
    train_epi = preprocess(train_file, [6, 7, 8, 9])
    train_y = train_y.reshape(len(train_y), -1)

    test_data = pd.read_csv(test_file, usecols=[5, 8])
    test_data = np.array(test_data)
    test_seq = test_data[:, 0]
    test_seq = grna_preprocess(test_seq)
    test_epi = preprocess(test_file, [5, 6, 7,8])
    return train_seq, test_seq, train_epi, test_epi, train_y
    
def load_data2(train_file, test_file):

    train_data = pd.read_csv(train_file, usecols=[5, 10])
    train_data = np.array(train_data)
    train_seq, train_y = train_data[:, 0], train_data[:, 1]
    train_seq = grna_preprocess(train_seq)
    train_epi = preprocess(train_file, [6, 7, 8, 9])
    train_y = train_y.reshape(len(train_y), -1)

    test_data = pd.read_csv(test_file, usecols=[4, 8])
    test_data = np.array(test_data)
    test_seq = test_data[:, 0] #, test_data[:, 1]
    test_seq = grna_preprocess(test_seq)
    test_epi = preprocess(test_file, [5, 6, 7, 8])
    #test_y = test_y.reshape(len(test_y), -1)
    return train_seq, test_seq, train_epi, test_epi, train_y

# Build model
def build_model():
    dropout = 0.3
    seq_input = Input(shape=(23, 4))
    seq_conv1 = Convolution1D(256, 5, kernel_initializer='glorot_uniform', name='seq_conv_1')(seq_input)
    seq_act1 = Activation('relu', name='seq_activation1')(seq_conv1)
    seq_pool1 = AveragePooling1D(2, name='seq_pooling_1')(seq_act1)
    seq_drop1 = Dropout(dropout)(seq_pool1)

    seq_conv2 = Convolution1D(256, 5, kernel_initializer='glorot_uniform', name='seq_conv_2')(seq_drop1)
    seq_act2 = Activation('relu', name='seq_activation_2')(seq_conv2)
    seq_pool2 = AveragePooling1D(2, name='seq_pooling_2')(seq_act2)
    seq_drop2 = Dropout(dropout)(seq_pool2)
    seq_flat = Flatten()(seq_drop2)

    seq_dense1 = Dense(256, activation='relu', name='seq_dense_1')(seq_flat)
    seq_drop3 = Dropout(dropout)(seq_dense1)
    seq_dense2 = Dense(128, activation='relu', name='seq_dense_2')(seq_drop3)
    seq_drop4 = Dropout(dropout)(seq_dense2)
    seq_dense3 = Dense(64, activation='relu', name='seq_dense_3')(seq_drop4)
    seq_drop5 = Dropout(dropout)(seq_dense3)
    seq_out = Dense(40, activation='relu', name='seq_dense_4')(seq_drop5)

    epi_input = Input(shape=(23, 4))
    epi_conv1 = Convolution1D(256, 5, kernel_initializer='glorot_uniform', name='epi_conv_1')(epi_input)
    epi_act1 = Activation('relu', name='epi_activation_1')(epi_conv1)
    epi_pool1 = AveragePooling1D(2, name='epi_pooling_1')(epi_act1)
    epi_drop1 = Dropout(dropout)(epi_pool1)

    epi_conv2 = Convolution1D(256, 5, kernel_initializer='glorot_uniform', name='epi_conv_2')(epi_drop1)
    epi_act2 = Activation('relu', name='epi_activation_2')(epi_conv2)
    epi_pool2 = AveragePooling1D(2, name='epi_pooling_2')(epi_act2)
    epi_drop2 = Dropout(dropout)(epi_pool2)
    epi_flat = Flatten()(epi_drop2)

    epi_dense1 = Dense(256, activation='relu', name='epi_dense_1')(epi_flat)
    epi_drop3 = Dropout(dropout)(epi_dense1)
    epi_dense2 = Dense(128, activation='relu', name='epi_dense_2')(epi_drop3)
    epi_drop4 = Dropout(dropout)(epi_dense2)
    epi_dense3 = Dense(64, activation='relu', name='epi_dense_3')(epi_drop4)
    epi_drop5 = Dropout(dropout)(epi_dense3)
    epi_out = Dense(40, activation='relu', name='epi_dense_4')(epi_drop5)

    merged = concatenate([seq_out, epi_out], axis=-1)

    pretrain_model = Model(inputs=[seq_input, epi_input], outputs=[merged])

    # Load weights for the model
    pretrain_model.load_weights("/content/drive/MyDrive/CNN-SVR-master/weights/weights.h5", by_name=True)

    prediction = Dense(1, activation='linear', name='prediction')(merged)
    model = Model([seq_input, epi_input], prediction)
    return merged, model



if __name__ == '__main__':

   Datasets = ['HCT116 - HCT116.csv']
   for DS in Datasets:
     train_path = "/content/drive/MyDrive/CNN-XG-main/data/"+str(DS)
     print("[+] loading Dataset " +str(DS))
     print('++++++++')
     df=pd.read_csv("/content/drive/MyDrive/CNN-XG-main/data/"+str(DS))
     X = df.drop('Efficacy', axis=1)
     y = df['Efficacy']
     kf = KFold(n_splits=5)
     i = 1
     for train_set, test_set in kf.split(X,y):

        train = df.loc[train_set,:]
        train.to_csv('/content/drive/MyDrive/CNN-XG-main/data/train'+str(DS)+""+str(i))

        test = df.loc[test_set,:]
        test.to_csv('/content/drive/MyDrive/CNN-XG-main/data/test'+str(DS)+""+str(i))

        train = "/content/drive/MyDrive/CNN-XG-main/data/train"+str(DS)+""+str(i)
        test = "/content/drive/MyDrive/CNN-XG-main/data/test"+str(DS)+""+str(i)
        test2 ="/content/drive/MyDrive/CNN-SVR-master/data/FLGsecondSelect.csv"

        
        seq_train, seq_test, epi_train, epi_test, y_train = load_data2(train, test2)
        #seq_test2, epi_test2 = load_data2(xx)
        

        merged, model = build_model()

        new_model = Model(model.inputs, outputs=[merged])
        x_train = new_model.predict([seq_train, epi_train])
        x_test = new_model.predict([seq_test, epi_test])
        #x_test2 = new_model.predict([seq_test2, epi_test2])

        #x_train, x_test = np.array(x_train), np.array(x_test)

        # Select important features from initial CNN features
        selected_cnn_fea_cols = [17, 26, 9, 19, 30, 6, 12, 39, 36, 21, 22, 3, 25]
        x_train = x_train[:, selected_cnn_fea_cols]
        x_test = x_test[:, selected_cnn_fea_cols]
        #x_test2 = x_test2[:, selected_cnn_fea_cols]

        #y_train = np.array(y_train).ravel()
        #y_test = np.array(y_test).ravel()

        print("iteration ", i)
        from sklearn.svm import SVC
        svm=SVC(probability=True,kernel='rbf')

        #clf = SVR(kernel="rbf", gamma=0.12, C=1.7, epsilon=0.11, verbose=1)
        #clf = SVC(gamma=0.12)
        #SVC(C=1.7, degree=3, gamma=0.12, kernel='rbf', verbose=1)
        y_train=y_train.astype('int') 
        svm.fit(x_train, y_train)


        y_pred = svm.predict(x_test)

        for i in y_pred:
          print(i)
        #print(y_pred)

        #y_test = np.array(y_test).ravel()
        #y_test = list(y_test)
        #y_pred2 = svm.predict(x_test2)
        #y_test = y_test.astype(int)
        #print(y_pred2)
        #print("ROCAUC " +str(DS)+" "+str(i))
        #acu = roc_auc_score(y_test, y_pred)
        #print(acu)
   

        print("-------------------------")
        i += 1
          
    
      

    


        





























